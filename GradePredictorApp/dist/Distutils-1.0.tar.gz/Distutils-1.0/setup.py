from distutils.core import setup

setup(name='Distutils',
      version='1.0',
      description='code for running predictives modeling tasks',
      author='Espoir Murhabazi',
      author_email='espoir.mur@gmail.com',
      url='https://github.com/espoirMur/Memory-Working-Dir',
      packages=['codes'],
     )
