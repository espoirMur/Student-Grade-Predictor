from distutils.core import setup
setup(name='predictives_models_building',
      version='1.0',
      description='code for running predictives modeling tasks',
      author='Espoir Murhabazi',
      author_email='espoir.mur@gmail.com',
      url='https://github.com/espoirMur/Memory-Working-Dir',
      py_modules=['predictiveModelBuilding'],
     )
